# Taller: Suricata IDS + GenAI — Notificación automática y persistente por correo y WhatsApp

**Electiva:** Seguridad de la Información apoyada con GenAI
**Modalidad:** Individual o en pareja (según lo defina el docente)
**Nivel:** Maestría — requiere nociones básicas de Linux y redes
**Duración estimada:** 3 a 4 horas

---

## 1. Objetivo del taller

Configurar un flujo de trabajo automático y persistente en el que:

1. **Suricata IDS** detecta una amenaza en el tráfico de red.
2. Un **servicio Python** monitorea el log de Suricata en tiempo real.
3. Al aparecer una nueva alerta, el evento se envía a una **API de GenAI**, que genera:
   - un **informe ejecutivo** de la amenaza, y
   - un **checklist de auditoría** para que el analista confirme si es un incidente real.
4. El informe y el checklist se envían automáticamente por **correo electrónico** y **WhatsApp**.
5. Todo el proceso queda corriendo como **servicio del sistema operativo** (systemd), por lo que sigue funcionando de manera persistente aunque se reinicie el servidor.

Este taller conecta directamente con los Bloques de la Sesión 3 (Gestión de incidentes apoyada con GenAI) y la Sesión 2 (riesgos de la GenAI: aquí se maneja información de seguridad real, por lo que el manejo de credenciales y datos es parte de la evaluación).

---

## 2. Arquitectura general

El flujo completo es el siguiente:

```
Tráfico de red
      │
      ▼
 Suricata IDS  ──────────────► eve.json (log de alertas)
                                     │
                                     ▼
                        Watcher persistente (Python + systemd)
                                     │
                                     ▼
                         GenAI (API Claude) → informe + checklist
                                     │
                        ┌────────────┴────────────┐
                        ▼                         ▼
                    Correo (SMTP)           WhatsApp (Twilio)
```

*(Este mismo diagrama se mostró de forma interactiva en la conversación; cada caja representa un paso que se configura en una sección de esta guía.)*

---

## 3. Prerrequisitos

| Componente | Detalle |
|---|---|
| Sistema operativo | Ubuntu 22.04 LTS o superior (recomendado), acceso root/sudo |
| Suricata | Versión 6.x o 7.x |
| Python | 3.10 o superior |
| Cuenta de GenAI | API key de Anthropic (Claude) — ver [console.anthropic.com](https://console.anthropic.com) |
| Cuenta de correo | Cuenta SMTP con "contraseña de aplicación" (Gmail, Outlook, u otro proveedor) |
| Cuenta de Twilio | Cuenta gratuita con el sandbox de WhatsApp habilitado — ver [twilio.com/whatsapp](https://www.twilio.com/whatsapp) |
| Permisos | Acceso de administrador para instalar paquetes y crear servicios systemd |

**Nota de seguridad importante:** este taller maneja credenciales reales (API keys, contraseñas SMTP, tokens de Twilio). Nunca deben subirse a un repositorio público ni compartirse en el informe de entrega. Se explica el manejo correcto en la sección 10.

---

## 4. Paso 1 — Instalar y configurar Suricata

### 4.1 Instalación

```bash
sudo apt update
sudo apt install -y suricata
```

### 4.2 Identificar la interfaz de red a monitorear

```bash
ip a
```

Anota el nombre de la interfaz activa (por ejemplo `eth0`, `ens33` o `wlan0`).

### 4.3 Configurar la interfaz en Suricata

Editar el archivo de configuración principal:

```bash
sudo nano /etc/suricata/suricata.yaml
```

Buscar la sección `af-packet` y ajustar la interfaz:

```yaml
af-packet:
  - interface: ens33   # reemplazar por la interfaz identificada en 4.2
```

### 4.4 Actualizar las reglas de detección

```bash
sudo suricata-update
sudo systemctl restart suricata
```

### 4.5 Verificar que Suricata está corriendo y generando el log EVE JSON

```bash
sudo systemctl status suricata
sudo tail -f /var/log/suricata/eve.json
```

Debe verse un flujo continuo de eventos en formato JSON (tipo `flow`, `dns`, `http`, etc.). Los eventos de tipo `alert` son los que activarán el watcher.

---

## 5. Paso 2 — Preparar el entorno del proyecto

### 5.1 Crear usuario y carpetas dedicadas (buena práctica de seguridad)

```bash
sudo useradd --system --no-create-home genai-watcher
sudo mkdir -p /opt/genai-watcher /etc/genai-watcher /var/log/genai-watcher
sudo chown -R genai-watcher:genai-watcher /var/log/genai-watcher
```

### 5.2 Copiar los archivos del proyecto

Copiar los siguientes archivos (entregados junto con esta guía) a `/opt/genai-watcher/`:

- `suricata_watcher.py`
- `requirements.txt`

```bash
sudo cp suricata_watcher.py requirements.txt /opt/genai-watcher/
```

### 5.3 Instalar dependencias de Python

```bash
cd /opt/genai-watcher
sudo pip3 install -r requirements.txt
```

### 5.4 Configurar las variables de entorno

Copiar el archivo de ejemplo y completarlo con las credenciales reales:

```bash
sudo cp .env.example /etc/genai-watcher/.env
sudo nano /etc/genai-watcher/.env
sudo chmod 600 /etc/genai-watcher/.env
sudo chown genai-watcher:genai-watcher /etc/genai-watcher/.env
```

`chmod 600` asegura que solo el usuario `genai-watcher` pueda leer el archivo con las credenciales.

---

## 6. Paso 3 — Obtener las credenciales necesarias

### 6.1 API key de GenAI (Claude)

1. Crear una cuenta en [console.anthropic.com](https://console.anthropic.com).
2. Generar una API key en la sección de configuración.
3. Copiarla en la variable `ANTHROPIC_API_KEY` del archivo `.env`.

### 6.2 Credenciales SMTP

Si se usa Gmail:
1. Activar la verificación en dos pasos en la cuenta de Google.
2. Generar una "contraseña de aplicación" específica (Google la entrega en `myaccount.google.com/apppasswords`).
3. Usar esa contraseña (no la contraseña normal de la cuenta) en `SMTP_PASS`.

### 6.3 Credenciales de WhatsApp (Twilio Sandbox)

1. Crear una cuenta gratuita en [twilio.com](https://www.twilio.com).
2. Activar el "WhatsApp Sandbox" desde la consola de Twilio.
3. Enviar desde el WhatsApp personal el código de activación que indica la consola (por ejemplo `join <palabra-clave>`) al número de sandbox de Twilio. Esto autoriza recibir mensajes de prueba en ese número.
4. Copiar `Account SID` y `Auth Token` en las variables `TWILIO_SID` y `TWILIO_TOKEN`.
5. El número `TWILIO_WHATSAPP_FROM` es el número de sandbox de Twilio (aparece en la consola, formato `whatsapp:+14155238886`).
6. El número `WHATSAPP_TO` es el número personal que se autorizó en el paso 3, en formato `whatsapp:+57XXXXXXXXXX`.

---

## 7. Paso 4 — Entender el script del watcher

El archivo `suricata_watcher.py` hace cinco cosas, en este orden:

1. **`tail_f()`**: lee el archivo `eve.json` de forma continua, línea por línea, igual que el comando `tail -f`, sin perder eventos nuevos.
2. **`procesar_alerta()`**: filtra solo los eventos de tipo `"event_type": "alert"` y descarta el resto (flows, DNS, HTTP, etc.), para no saturar de notificaciones.
3. **`generar_informe_genai()`**: envía el JSON crudo de la alerta a la API de Claude con un prompt que le pide devolver un informe ejecutivo y un checklist de auditoría, en un formato predecible que el script puede separar automáticamente.
4. **`enviar_correo()`** y **`enviar_whatsapp()`**: toman el informe y el checklist generados y los distribuyen por los dos canales configurados.
5. **`main()`**: mantiene todo el ciclo corriendo indefinidamente.

Se recomienda leer el archivo completo antes de continuar, ya que el taller pide modificarlo en el Paso 8 (sección 11).

---

## 8. Paso 5 — Prueba manual (antes de hacerlo persistente)

Antes de convertirlo en servicio, se recomienda correrlo manualmente para verificar que todo funciona:

```bash
cd /opt/genai-watcher
sudo -u genai-watcher env $(cat /etc/genai-watcher/.env | xargs) python3 suricata_watcher.py
```

Debe aparecer en la terminal:

```
INFO Iniciando monitoreo persistente de /var/log/suricata/eve.json ...
```

Dejar esta terminal abierta y, en otra terminal, generar una alerta de prueba (ver Paso 7). Si todo está bien configurado, en la misma terminal debe aparecer:

```
INFO Nueva alerta detectada: GPL ATTACK_RESPONSE id check returned root (severidad 2)
INFO Correo enviado correctamente.
INFO Mensaje de WhatsApp enviado correctamente.
```

---

## 9. Paso 6 — Generar una alerta de prueba

Para no depender de tráfico malicioso real, se usa un servicio público diseñado exactamente para esto: `testmyids.com`, que activa una firma de prueba inofensiva de los IDS.

Ejecutar el script entregado:

```bash
chmod +x test_alert.sh
./test_alert.sh
```

O manualmente:

```bash
curl http://testmyids.com/
```

Esto debe generar una alerta con la firma `GPL ATTACK_RESPONSE id check returned root` (o similar, según el ruleset activo) visible en `eve.json`.

---

## 10. Paso 7 — Hacerlo persistente con systemd

Una vez verificado que el script funciona manualmente, se configura como servicio para que:

- Inicie automáticamente al arrancar el servidor.
- Se reinicie solo si falla (`Restart=always`).
- Quede corriendo en segundo plano sin necesidad de una terminal abierta.

### 10.1 Copiar la unidad de systemd

```bash
sudo cp genai-watcher.service /etc/systemd/system/
```

### 10.2 Recargar systemd y habilitar el servicio

```bash
sudo systemctl daemon-reload
sudo systemctl enable genai-watcher.service
sudo systemctl start genai-watcher.service
```

### 10.3 Verificar el estado y los logs

```bash
sudo systemctl status genai-watcher.service
sudo journalctl -u genai-watcher.service -f
```

o directamente:

```bash
sudo tail -f /var/log/genai-watcher/watcher.log
```

### 10.4 Prueba de persistencia

```bash
sudo reboot
```

Después de que el servidor reinicie, verificar que el servicio arrancó solo:

```bash
sudo systemctl status genai-watcher.service
```

Repetir la prueba de la sección 9 y confirmar que las notificaciones siguen llegando sin haber vuelto a ejecutar nada manualmente.

---

## 11. Paso 8 — Personalización obligatoria (parte evaluable)

Para que el taller no sea una simple copia del código entregado, cada estudiante debe realizar **al menos dos** de las siguientes modificaciones y documentarlas en su informe:

1. **Filtrado adicional**: modificar `procesar_alerta()` para ignorar alertas provenientes de una lista blanca de IPs internas conocidas.
2. **Enriquecimiento del prompt**: modificar `generar_informe_genai()` para que el informe incluya también una clasificación según el marco **MITRE ATT&CK** (táctica y técnica probable).
3. **Nuevo canal de salida**: agregar el envío a un canal adicional (por ejemplo, un webhook de Slack o Microsoft Teams).
4. **Umbral de repetición**: implementar una lógica que evite notificar la misma firma de alerta más de una vez cada X minutos (para prevenir saturación por ráfagas de alertas repetidas).
5. **Panel de severidad**: modificar el correo HTML para que el color del encabezado cambie según la severidad (rojo para severidad 1, ámbar para 2, gris para 3).

---

## 12. Paso 9 — Verificación final (checklist de entrega)

El estudiante debe confirmar y documentar con evidencia (capturas de pantalla) cada uno de los siguientes puntos:

- [ ] Suricata está instalado, corriendo, y generando eventos en `eve.json`.
- [ ] El script `suricata_watcher.py` corre manualmente sin errores.
- [ ] Una alerta de prueba (`testmyids.com` u otra) genera un informe y un checklist coherentes.
- [ ] El correo electrónico llega correctamente con el informe y el checklist.
- [ ] El mensaje de WhatsApp llega correctamente con el resumen.
- [ ] El servicio systemd está habilitado (`enabled`) y activo (`active (running)`).
- [ ] Tras un reinicio del servidor, el servicio vuelve a levantarse automáticamente.
- [ ] Se implementaron al menos dos personalizaciones de la sección 11.
- [ ] El archivo `.env` con credenciales reales **no** se incluye en el informe ni en ningún repositorio.

---

## 13. Consideraciones de seguridad y buenas prácticas

Estas consideraciones conectan directamente con los riesgos de la GenAI vistos en la Sesión 2 del curso:

- **Fuga de datos**: el JSON de Suricata puede contener IPs internas, nombres de host o metadatos sensibles de la red. Antes de enviarlo a una API externa de GenAI, evaluar si es necesario anonimizar o enmascarar campos sensibles según las políticas de la organización.
- **Gestión de credenciales**: nunca hardcodear API keys, contraseñas o tokens directamente en el código. Usar siempre variables de entorno (`.env` con permisos `600`, o un gestor de secretos como Vault/AWS Secrets Manager en producción).
- **Rate limiting**: si el volumen de alertas es alto, considerar agrupar alertas similares antes de llamar a la API de GenAI, para controlar costos y evitar saturar los canales de notificación.
- **Dependencia excesiva (overreliance)**: el informe y el checklist generados por GenAI son una ayuda a la decisión, no un reemplazo del criterio del analista. El checklist siempre debe ser ejecutado y validado por una persona.
- **Disponibilidad del servicio**: si la API de GenAI no responde (ver bloque `try/except` en `procesar_alerta()`), el script debe seguir funcionando y registrar el error en el log, sin caerse.

---

## 14. Archivos entregados junto con esta guía

| Archivo | Propósito |
|---|---|
| `suricata_watcher.py` | Script principal: monitoreo, GenAI, correo y WhatsApp |
| `.env.example` | Plantilla de variables de entorno (copiar como `.env` y completar) |
| `requirements.txt` | Dependencias de Python a instalar |
| `genai-watcher.service` | Unidad de systemd para persistencia |
| `test_alert.sh` | Script para generar una alerta de prueba inofensiva |

---

## 15. Referencias (norma IEEE)

[1] OISF, "Suricata User Guide," Open Information Security Foundation, 2025. [Online]. Available: https://docs.suricata.io/

[2] Anthropic, "Messages API reference," Anthropic Docs, 2025. [Online]. Available: https://docs.claude.com/

[3] Twilio Inc., "WhatsApp API for Python Quickstart," Twilio Docs, 2025. [Online]. Available: https://www.twilio.com/docs/whatsapp/quickstart/python

[4] OWASP Foundation, "OWASP Top 10 for Large Language Model Applications," 2025. [Online]. Available: https://owasp.org/www-project-top-10-for-large-language-model-applications/

[5] National Institute of Standards and Technology, "Artificial intelligence risk management framework: Generative artificial intelligence profile," NIST AI 600-1, Gaithersburg, MD, USA, Jul. 2024.
