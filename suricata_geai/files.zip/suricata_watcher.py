#!/usr/bin/env python3
"""
suricata_watcher.py
--------------------
Monitorea de forma persistente el archivo eve.json de Suricata. Cuando aparece
un nuevo evento de tipo "alert", envía el evento a una API de GenAI para
generar (1) un informe ejecutivo y (2) un checklist de auditoría, y distribuye
el resultado por correo electrónico y WhatsApp (vía Twilio).

Diseñado para ejecutarse como servicio systemd (ver genai-watcher.service),
de modo que quede corriendo de manera automática y persistente en el host.
"""

import os
import json
import time
import smtplib
import ssl
import logging
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime

import requests
from twilio.rest import Client

# Carga opcional de un archivo .env para pruebas manuales en local.
# Cuando el script corre como servicio systemd, las variables ya llegan
# inyectadas por la directiva EnvironmentFile (ver genai-watcher.service),
# por lo que este bloque simplemente no encuentra nada que hacer y continúa.
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

# ============================================================
# CONFIGURACIÓN (leída desde variables de entorno — ver .env.example)
# ============================================================
EVE_JSON_PATH = os.getenv("EVE_JSON_PATH", "/var/log/suricata/eve.json")

ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY")
ANTHROPIC_MODEL = os.getenv("ANTHROPIC_MODEL", "claude-sonnet-4-6")

SMTP_HOST = os.getenv("SMTP_HOST")
SMTP_PORT = int(os.getenv("SMTP_PORT", "587"))
SMTP_USER = os.getenv("SMTP_USER")
SMTP_PASS = os.getenv("SMTP_PASS")
EMAIL_TO = os.getenv("EMAIL_TO")

TWILIO_SID = os.getenv("TWILIO_SID")
TWILIO_TOKEN = os.getenv("TWILIO_TOKEN")
TWILIO_WHATSAPP_FROM = os.getenv("TWILIO_WHATSAPP_FROM")  # ej: "whatsapp:+14155238886"
WHATSAPP_TO = os.getenv("WHATSAPP_TO")                    # ej: "whatsapp:+57XXXXXXXXXX"

# Severidad mínima a notificar. En Suricata, 1 = más severo, 3 = menos severo.
# SEVERITY_MAX = 3 significa: notificar severidad 1, 2 y 3 (todas).
SEVERITY_MAX = int(os.getenv("SEVERITY_MAX", "3"))

LOG_PATH = os.getenv("WATCHER_LOG_PATH", "/var/log/genai-watcher/watcher.log")

# ============================================================
# LOGGING
# ============================================================
os.makedirs(os.path.dirname(LOG_PATH), exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[logging.FileHandler(LOG_PATH), logging.StreamHandler()]
)
log = logging.getLogger("genai-watcher")


# ============================================================
# 1. LECTURA PERSISTENTE DEL LOG (equivalente a `tail -f`)
# ============================================================
def tail_f(path):
    """Generador infinito que va entregando líneas nuevas del archivo,
    igual que `tail -f`. Si el archivo aún no existe, espera a que aparezca."""
    while not os.path.exists(path):
        log.warning(f"Esperando a que exista {path} ...")
        time.sleep(5)

    with open(path, "r") as f:
        f.seek(0, os.SEEK_END)  # ir al final: solo interesan eventos NUEVOS
        while True:
            line = f.readline()
            if not line:
                time.sleep(1)
                continue
            yield line


# ============================================================
# 2. INTEGRACIÓN CON GENAI: genera informe + checklist
# ============================================================
def generar_informe_genai(event: dict) -> tuple[str, str]:
    """Envía el evento crudo de Suricata a la API de Claude y devuelve
    (informe, checklist) como texto ya separado."""

    prompt = f"""Eres un analista de seguridad de un SOC (Security Operations Center).
A continuación se te entrega el JSON crudo de una alerta generada por Suricata IDS.

Genera tu respuesta con EXACTAMENTE estos dos encabezados, en este orden:

### INFORME
Un informe ejecutivo de máximo 150 palabras que explique: qué tipo de amenaza
representa esta alerta, cuáles son sus indicadores clave (IP origen, IP destino,
puerto, protocolo, firma de la regla y severidad), y el posible impacto si se
confirma como un incidente real.

### CHECKLIST
Una lista numerada de 5 a 8 pasos concretos y accionables que el analista de
turno debe seguir para auditar esta alerta y determinar si es un incidente real
o un falso positivo.

Datos de la alerta (JSON crudo de Suricata):
{json.dumps(event, indent=2, ensure_ascii=False)}
"""

    headers = {
        "x-api-key": ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
        "content-type": "application/json",
    }
    payload = {
        "model": ANTHROPIC_MODEL,
        "max_tokens": 900,
        "messages": [{"role": "user", "content": prompt}],
    }

    resp = requests.post(
        "https://api.anthropic.com/v1/messages",
        headers=headers,
        json=payload,
        timeout=30,
    )
    resp.raise_for_status()
    data = resp.json()
    texto = "".join(b["text"] for b in data["content"] if b.get("type") == "text")

    if "### CHECKLIST" in texto:
        partes = texto.split("### CHECKLIST")
        informe = partes[0].replace("### INFORME", "").strip()
        checklist = partes[1].strip()
    else:
        # Si el modelo no siguió el formato exacto, se envía todo como informe.
        informe, checklist = texto.strip(), "(No se pudo separar el checklist; ver informe completo.)"

    return informe, checklist


# ============================================================
# 3. CONSTRUCCIÓN DE MENSAJES
# ============================================================
def construir_cuerpo_email(event: dict, informe: str, checklist: str) -> str:
    alert = event.get("alert", {})
    fecha = event.get("timestamp", datetime.now().isoformat())

    return f"""\
<html><body style="font-family:Arial,sans-serif;font-size:14px;color:#1a1a1a;">
<h2 style="color:#0E1630;">Nueva alerta de Suricata IDS</h2>
<table style="border-collapse:collapse;margin-bottom:16px;">
<tr><td style="padding:4px 10px;font-weight:bold;">Fecha</td><td style="padding:4px 10px;">{fecha}</td></tr>
<tr><td style="padding:4px 10px;font-weight:bold;">Firma</td><td style="padding:4px 10px;">{alert.get('signature','N/D')}</td></tr>
<tr><td style="padding:4px 10px;font-weight:bold;">Severidad</td><td style="padding:4px 10px;">{alert.get('severity','N/D')}</td></tr>
<tr><td style="padding:4px 10px;font-weight:bold;">IP origen</td><td style="padding:4px 10px;">{event.get('src_ip','N/D')}:{event.get('src_port','')}</td></tr>
<tr><td style="padding:4px 10px;font-weight:bold;">IP destino</td><td style="padding:4px 10px;">{event.get('dest_ip','N/D')}:{event.get('dest_port','')}</td></tr>
<tr><td style="padding:4px 10px;font-weight:bold;">Protocolo</td><td style="padding:4px 10px;">{event.get('proto','N/D')}</td></tr>
</table>

<h3 style="color:#3D6B99;">Informe generado por GenAI</h3>
<p style="white-space:pre-wrap;">{informe}</p>

<h3 style="color:#3D6B99;">Checklist de auditoría del evento</h3>
<p style="white-space:pre-wrap;">{checklist}</p>

<hr>
<p style="font-size:11px;color:#888;">Mensaje generado automáticamente por el watcher Suricata + GenAI.
Este análisis es una ayuda a la decisión; debe ser validado por un analista humano.</p>
</body></html>
"""


def construir_resumen_whatsapp(event: dict, informe: str) -> str:
    alert = event.get("alert", {})
    resumen_informe = informe[:400] + ("..." if len(informe) > 400 else "")
    return (
        f"🚨 *Nueva alerta Suricata*\n"
        f"Firma: {alert.get('signature','N/D')}\n"
        f"Severidad: {alert.get('severity','N/D')}\n"
        f"Origen: {event.get('src_ip','N/D')} → Destino: {event.get('dest_ip','N/D')}\n\n"
        f"{resumen_informe}\n\n"
        f"Revisa tu correo para el informe completo y el checklist de auditoría."
    )


# ============================================================
# 4. ENVÍO POR CORREO (SMTP)
# ============================================================
def enviar_correo(cuerpo_html: str):
    msg = MIMEMultipart("alternative")
    msg["Subject"] = f"[SOC] Nueva alerta Suricata — {datetime.now().strftime('%Y-%m-%d %H:%M')}"
    msg["From"] = SMTP_USER
    msg["To"] = EMAIL_TO
    msg.attach(MIMEText(cuerpo_html, "html"))

    ctx = ssl.create_default_context()
    with smtplib.SMTP(SMTP_HOST, SMTP_PORT) as server:
        server.starttls(context=ctx)
        server.login(SMTP_USER, SMTP_PASS)
        server.sendmail(SMTP_USER, EMAIL_TO, msg.as_string())
    log.info("Correo enviado correctamente.")


# ============================================================
# 5. ENVÍO POR WHATSAPP (Twilio)
# ============================================================
def enviar_whatsapp(texto: str):
    client = Client(TWILIO_SID, TWILIO_TOKEN)
    client.messages.create(
        from_=TWILIO_WHATSAPP_FROM,
        to=WHATSAPP_TO,
        body=texto[:1550],  # límite práctico de longitud de mensaje
    )
    log.info("Mensaje de WhatsApp enviado correctamente.")


# ============================================================
# 6. PROCESAMIENTO DE CADA ALERTA
# ============================================================
def procesar_alerta(event: dict):
    alert = event.get("alert", {})
    severidad = alert.get("severity", 3)

    if severidad > SEVERITY_MAX:
        log.info(f"Alerta ignorada por severidad baja ({severidad}): {alert.get('signature')}")
        return

    log.info(f"Nueva alerta detectada: {alert.get('signature')} (severidad {severidad})")

    try:
        informe, checklist = generar_informe_genai(event)
    except Exception as e:
        log.error(f"Error al llamar a la API de GenAI: {e}")
        return

    try:
        enviar_correo(construir_cuerpo_email(event, informe, checklist))
    except Exception as e:
        log.error(f"Error al enviar el correo: {e}")

    try:
        enviar_whatsapp(construir_resumen_whatsapp(event, informe))
    except Exception as e:
        log.error(f"Error al enviar el mensaje de WhatsApp: {e}")


# ============================================================
# 7. BUCLE PRINCIPAL
# ============================================================
def main():
    log.info(f"Iniciando monitoreo persistente de {EVE_JSON_PATH} ...")
    for linea in tail_f(EVE_JSON_PATH):
        try:
            event = json.loads(linea)
        except json.JSONDecodeError:
            continue

        if event.get("event_type") == "alert":
            procesar_alerta(event)


if __name__ == "__main__":
    main()
