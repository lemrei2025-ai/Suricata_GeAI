#!/usr/bin/env bash
# test_alert.sh
# ------------------------------------------------------------
# Genera una alerta de prueba INOFENSIVA en Suricata usando el
# dominio público testmyids.com, diseñado específicamente para
# activar la firma de prueba de los IDS (SID 2100498 en muchos
# rulesets, "GPL ATTACK_RESPONSE id check returned root").
#
# No representa ningún riesgo: es un servicio público pensado
# para pruebas de laboratorio como esta.
# ------------------------------------------------------------

echo "[+] Enviando tráfico de prueba a testmyids.com ..."
curl -s http://testmyids.com/ > /dev/null

echo "[+] Tráfico enviado. Verifica en unos segundos:"
echo "    sudo tail -f /var/log/suricata/eve.json | grep alert"
echo ""
echo "[+] Si el watcher está corriendo (systemctl status genai-watcher),"
echo "    deberías recibir el correo y el mensaje de WhatsApp en menos de un minuto."
